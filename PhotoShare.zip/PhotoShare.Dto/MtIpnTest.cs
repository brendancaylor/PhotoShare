using System;
using System.Collections.Generic;

namespace PhotoShare.Dto
{
    public partial class MtIpnTest
    {
        public System.Guid Id { get; set; }
        public string IpnMessage { get; set; }
    }
}
