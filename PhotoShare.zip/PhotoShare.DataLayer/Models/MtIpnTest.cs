using System;
using System.Collections.Generic;

namespace PhotoShare.DataLayer.Models
{
    public partial class MtIpnTest
    {
        public System.Guid Id { get; set; }
        public string IpnMessage { get; set; }
    }
}
