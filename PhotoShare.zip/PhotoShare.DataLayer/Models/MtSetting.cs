using System;
using System.Collections.Generic;

namespace PhotoShare.DataLayer.Models
{
    public partial class MtSetting
    {
        public System.Guid ID { get; set; }
        public string DropboxAccessToken { get; set; }
        public string DropboxRootFolder { get; set; }
        public string PayPalId { get; set; }
    }
}
