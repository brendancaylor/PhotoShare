﻿CREATE TABLE [dbo].[MtIpnTest]
(
	[Id]            UNIQUEIDENTIFIER NOT NULL,
	[IpnMessage]  NVARCHAR (MAX)   NOT NULL,	
    CONSTRAINT [PK_MtIpnTest] PRIMARY KEY CLUSTERED ([Id] ASC)
)
